import { z } from "zod";
import { getGeminiClient } from "./client";
import { GEMINI_MODEL } from "./config";
import { SYSTEM_PROMPT, buildUserPrompt } from "./prompts";
import { AIContext } from "./context-builder";
import { AIOutput, AIOutputSchema } from "./output-schema";

/**
 * Dynamically converts a Zod schema object into the JSON Schema format expected by the Gemini API.
 * Supports basic primitives, objects, arrays, optionals, and nullables.
 */
export function zodToGeminiSchema(zodSchema: any): any {
  if (zodSchema instanceof z.ZodObject) {
    const shape = zodSchema.shape;
    const properties: Record<string, any> = {};
    const required: string[] = [];

    for (const key of Object.keys(shape)) {
      properties[key] = zodToGeminiSchema(shape[key]);
      const isOptional = shape[key] instanceof z.ZodOptional;
      if (!isOptional) {
        required.push(key);
      }
    }

    return {
      type: "object",
      properties,
      required: required.length > 0 ? required : undefined,
    };
  }

  if (zodSchema instanceof z.ZodArray) {
    return {
      type: "array",
      items: zodToGeminiSchema(zodSchema.element),
    };
  }

  if (zodSchema instanceof z.ZodNullable) {
    const innerSchema = zodToGeminiSchema(zodSchema.unwrap());
    return {
      ...innerSchema,
      nullable: true,
    };
  }

  if (zodSchema instanceof z.ZodOptional) {
    return zodToGeminiSchema(zodSchema.unwrap());
  }

  if (zodSchema instanceof z.ZodString) {
    return { type: "string" };
  }

  if (zodSchema instanceof z.ZodNumber) {
    return { type: "number" };
  }

  if (zodSchema instanceof z.ZodBoolean) {
    return { type: "boolean" };
  }

  // Fallback for basic typing
  return { type: "string" };
}

/**
 * Calls the Gemini API to generate structured profile insights for the given developer context.
 * Performs explicit JSON parsing and validates the structure using the application-level AIOutputSchema.
 */
export async function generateProfylInsights(context: AIContext): Promise<AIOutput> {
  const client = getGeminiClient();
  const contextJson = JSON.stringify(context);

  const response = await client.models.generateContent({
    model: GEMINI_MODEL,
    contents: buildUserPrompt(contextJson),
    config: {
      systemInstruction: SYSTEM_PROMPT,
      responseMimeType: "application/json",
      responseSchema: zodToGeminiSchema(AIOutputSchema),
    },
  });

  const text = response.text;
  if (!text || text.trim() === "") {
    throw new Error("Gemini API returned an empty text response.");
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch (error: any) {
    throw new Error(
      `Failed to parse Gemini JSON response: ${error.message}. Raw text: ${text}`
    );
  }

  return AIOutputSchema.parse(parsed);
}
